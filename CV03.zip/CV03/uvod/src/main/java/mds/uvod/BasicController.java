package mds.uvod;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("basic")
public class BasicController {

    @GetMapping
    public String test(){
        return "<b>Hello MDS!</b>";
    }

    @GetMapping("list")
    public List<String> testList(){
        return List.of("Hello", "world", "in", "JSON");
    }
    @GetMapping("test1")
    public String testParam1(@RequestParam(defaultValue = "user") String name){
        return String.format("Hello %s Welcome to our page!",name);
    }

    @GetMapping("test2")
    public String testParam2(@RequestParam(defaultValue = "user", name = "meno") String name2){
        return String.format("Hello %s Welcome to our page!", name2);
    }

    @GetMapping("test3")
    public String testParam3(@RequestParam List<String> id){
        return "All IDs are:" + id;
    }

    @GetMapping("form")
    public String helloForm(){
        String html =
                "<html>"+
                        "<body>"+
                            "<form method ='post' action='hello'>"+
                                "<input type ='text' name='name'/>"+
                                "<input type ='submit' value='Pozdrav'/>"+
                            "</form>"+
                        "</body>"+
                "</html>";

        return html;
    }
    @RequestMapping(value = "hello", method = {RequestMethod.POST, RequestMethod.GET})
    public String helloTest(@RequestParam String name){
        return String.format("Hello %s Welcome to our page!",name);
    }

}
