package mds.uvod;

public class Student {
    private String surname,name;
    private int id, year;

    public Student(String surname, String name, int id, int year)
    {
        this.surname = surname;
        this.name = name;
        this.id = id;
        this.year = year;
    }

    @Override
    public String toString(){
        return surname + " " + name + " " + id + " " + year;
    }

    public int getId() {
        return this.id;
    }
}
